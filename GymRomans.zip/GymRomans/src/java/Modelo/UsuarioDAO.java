
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class UsuarioDAO {
    PreparedStatement ps;
    ResultSet rs;
    Conexion c=new Conexion();
    Connection con;
    
    public List listar(){
        
        List<Usuario>lista=new ArrayList<>();
        String sql="select * from USUARIO";
        try{
            con=c.conectar();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            
            while(rs.next()){
            Usuario usuario=new Usuario();
            usuario.setCedula(rs.getString(1));
            usuario.setNombre(rs.getString(2));
            usuario.setApellidoP(rs.getString(3));
            usuario.setApellidoM(rs.getString(4));
            usuario.setEdad(rs.getString(5));
            usuario.setPeso(rs.getString(6));
            usuario.setTalla(rs.getString(7));
            usuario.setEmail(rs.getString(8));
            lista.add(usuario);
            
        }
        }catch (Exception e){
           
        }
        return lista;
    }
}
